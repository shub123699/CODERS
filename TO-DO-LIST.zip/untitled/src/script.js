document.getElementById('addTaskButton').addEventListener('click', addTask);

function addTask() {
    const taskInput = document.getElementById('taskInput');
    const taskText = taskInput.value.trim();

    if (taskText === '') {
        alert('Please enter a task!');
        return;
    }

    const taskList = document.getElementById('taskList');
    const li = document.createElement('li');

    li.textContent = taskText;

    // Create a complete button
    const completeButton = document.createElement('button');
    completeButton.textContent = 'Complete';
    completeButton.classList.add('complete-button');
    completeButton.addEventListener('click', () => {
        li.classList.toggle('completed');
        if (li.classList.contains('completed')) {
            completeButton.textContent = 'Undo';
        } else {
            completeButton.textContent = 'Complete';
        }
    });

    // Create a delete button
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.classList.add('delete-button');
    deleteButton.addEventListener('click', () => {
        li.classList.add('fade-out');
        setTimeout(() => {
            taskList.removeChild(li);
        }, 300); // Wait for the fade-out animation to finish
    });

    li.appendChild(completeButton);
    li.appendChild(deleteButton);
    taskList.appendChild(li);

    // Add animation for adding a task
    li.classList.add('fade-in');
    setTimeout(() => {
        li.classList.remove('fade-in');
    }, 300); // Remove the fade-in class after the animation

    taskInput.value = ''; // Clear the input
}